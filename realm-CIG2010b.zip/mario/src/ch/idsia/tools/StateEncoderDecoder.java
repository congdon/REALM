package ch.idsia.tools;

/**
 * Created by IntelliJ IDEA.
 * User: Sergey Karakovskiy, firstname_at_idsia_dot_ch
 * Date: Aug 5, 2009
 * Time: 3:11:31 PM
 * Package: ch.idsia.tools
 */
public class StateEncoderDecoder
{
//    public static String Encode(byte[][] raw_observation) {
//
//    }
//
//    public static byte[][] Decode(String encoded_obs) {
//
//    }

}
